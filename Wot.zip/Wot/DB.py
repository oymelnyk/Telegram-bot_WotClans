#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# vim:fileencoding=utf-8
import pypyodbc


connection = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};''Server=192.168.0.224;Port=1433;UID=USER;PWD=Qq_1234567;Database=b_telegram;') #ODBC Driver 17 for SQL Server
cursor= connection.cursor()

SQL_SELECT_TOP_50="""
                    SELECT TOP (50)
                    [efficiency_rank],
                    [clan_tag],
                    [efficiency_rank_delta]  
                    FROM [b_telegram].[dbo].[Clans] 
                    ORDER BY efficiency_rank"""



SQL_DELETE_DATA_Clans="""
DELETE FROM [b_telegram].[dbo].[Clans]
"""



connection.commit()

